/**
 * Example Usage of Provider PDF Filler Utilities
 * 
 * This file demonstrates how to use the core utilities programmatically
 * without the React UI. Useful for automation scripts or testing.
 */

import { parseProviderCSV, generateProviderJSON } from './src/utils/csvParser';
import { extractPDFFields, generateFieldMappings, fillPDF, downloadPDF } from './src/utils/pdfUtils';
import * as fs from 'fs/promises';

// Example 1: Parse CSV and extract provider data
async function parseProviderData() {
  const csvContent = await fs.readFile('./provider-data.csv', 'utf-8');
  const parsedData = parseProviderCSV(csvContent);
  
  console.log(`Found ${parsedData.providers.length} providers`);
  console.log(`Available fields: ${parsedData.allFields.join(', ')}`);
  
  // Get first provider
  const firstProvider = parsedData.providers[0];
  console.log(`First provider: ${firstProvider.name}`);
  
  // Generate JSON for a specific provider
  const json = generateProviderJSON(firstProvider);
  await fs.writeFile('./sample-provider.json', json);
  
  return parsedData;
}

// Example 2: Analyze a PDF form
async function analyzePDFForm(pdfPath: string) {
  // In Node.js, you'd read the file as a buffer
  const buffer = await fs.readFile(pdfPath);
  const blob = new Blob([buffer]);
  const file = new File([blob], 'form.pdf', { type: 'application/pdf' });
  
  const fields = await extractPDFFields(file);
  
  console.log(`Found ${fields.length} fillable fields:`);
  fields.forEach(field => {
    console.log(`  - ${field.name} (${field.type})`);
  });
  
  return fields;
}

// Example 3: Generate field mappings
async function generateMappings(pdfPath: string, providerName: string) {
  // Parse provider data
  const csvContent = await fs.readFile('./provider-data.csv', 'utf-8');
  const parsedData = parseProviderCSV(csvContent);
  
  // Find specific provider
  const provider = parsedData.providers.find(p => p.name === providerName);
  if (!provider) {
    throw new Error(`Provider ${providerName} not found`);
  }
  
  // Extract PDF fields
  const buffer = await fs.readFile(pdfPath);
  const blob = new Blob([buffer]);
  const file = new File([blob], 'form.pdf', { type: 'application/pdf' });
  const pdfFields = await extractPDFFields(file);
  
  // Generate mappings
  const mappings = generateFieldMappings(pdfFields, provider);
  
  console.log(`Generated ${mappings.length} field mappings:`);
  mappings.forEach(mapping => {
    console.log(`  ${mapping.pdfField} → ${mapping.providerField}`);
    console.log(`    Confidence: ${Math.round(mapping.confidence * 100)}%`);
    console.log(`    Value: "${mapping.suggestedValue}"`);
    console.log();
  });
  
  return mappings;
}

// Example 4: Fill a PDF form
async function fillPDFForm(
  pdfPath: string,
  providerName: string,
  outputPath: string,
  customMappings?: Record<string, string>
) {
  // Parse provider data
  const csvContent = await fs.readFile('./provider-data.csv', 'utf-8');
  const parsedData = parseProviderCSV(csvContent);
  
  // Find provider
  const provider = parsedData.providers.find(p => p.name === providerName);
  if (!provider) {
    throw new Error(`Provider ${providerName} not found`);
  }
  
  // Read PDF
  const buffer = await fs.readFile(pdfPath);
  const blob = new Blob([buffer]);
  const file = new File([blob], 'form.pdf', { type: 'application/pdf' });
  
  // Fill PDF
  const filledPDF = await fillPDF(file, provider, customMappings);
  
  // Save to file
  await fs.writeFile(outputPath, filledPDF);
  
  console.log(`Filled PDF saved to ${outputPath}`);
}

// Example 5: Batch process multiple PDFs for one provider
async function batchProcessPDFs(
  providerName: string,
  pdfDirectory: string,
  outputDirectory: string
) {
  const files = await fs.readdir(pdfDirectory);
  const pdfFiles = files.filter(f => f.endsWith('.pdf'));
  
  console.log(`Processing ${pdfFiles.length} PDFs for ${providerName}...`);
  
  for (const pdfFile of pdfFiles) {
    const inputPath = `${pdfDirectory}/${pdfFile}`;
    const outputPath = `${outputDirectory}/${providerName.replace(/\s+/g, '_')}_${pdfFile}`;
    
    try {
      await fillPDFForm(inputPath, providerName, outputPath);
      console.log(`✓ ${pdfFile}`);
    } catch (error) {
      console.error(`✗ ${pdfFile}: ${error.message}`);
    }
  }
}

// Example 6: Create a mapping template
async function createMappingTemplate(pdfPath: string, outputPath: string) {
  const buffer = await fs.readFile(pdfPath);
  const blob = new Blob([buffer]);
  const file = new File([blob], 'form.pdf', { type: 'application/pdf' });
  
  const fields = await extractPDFFields(file);
  
  // Create template
  const template: Record<string, string> = {};
  fields.forEach(field => {
    template[field.name] = ''; // Empty, to be filled manually
  });
  
  await fs.writeFile(outputPath, JSON.stringify(template, null, 2));
  
  console.log(`Mapping template saved to ${outputPath}`);
  console.log('Edit this file to create custom field mappings.');
}

// Main execution examples
async function main() {
  // Example 1: Parse provider data
  await parseProviderData();
  
  // Example 2: Analyze a PDF
  await analyzePDFForm('./sample-form.pdf');
  
  // Example 3: Generate mappings
  await generateMappings('./sample-form.pdf', 'Doron Stember, MD');
  
  // Example 4: Fill a single PDF
  await fillPDFForm(
    './sample-form.pdf',
    'Doron Stember, MD',
    './filled-form.pdf'
  );
  
  // Example 5: Batch process
  await batchProcessPDFs(
    'Doron Stember, MD',
    './input-forms',
    './output-forms'
  );
  
  // Example 6: Create mapping template
  await createMappingTemplate('./sample-form.pdf', './mapping-template.json');
}

// Uncomment to run examples
// main().catch(console.error);

export {
  parseProviderData,
  analyzePDFForm,
  generateMappings,
  fillPDFForm,
  batchProcessPDFs,
  createMappingTemplate
};
