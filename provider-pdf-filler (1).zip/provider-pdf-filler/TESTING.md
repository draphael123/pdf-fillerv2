# Testing Guide

This guide covers testing the Provider PDF Form Filler application.

## Manual Testing Checklist

### 1. CSV Upload and Parsing

**Test Case 1.1: Valid CSV Upload**
- [ ] Upload the sample CSV file
- [ ] Verify all providers appear in the dropdown
- [ ] Verify provider count is correct
- [ ] Check that provider names are correctly parsed

**Test Case 1.2: CSV with Special Characters**
- [ ] Upload CSV with names containing commas, quotes
- [ ] Verify parsing handles quoted fields correctly
- [ ] Check multi-line addresses display properly

**Test Case 1.3: Invalid CSV**
- [ ] Upload a non-CSV file
- [ ] Verify error message appears
- [ ] Ensure app doesn't crash

### 2. Provider Selection

**Test Case 2.1: Provider Search**
- [ ] Type partial name in search
- [ ] Verify filtered results are correct
- [ ] Test case-insensitive search
- [ ] Clear search shows all providers again

**Test Case 2.2: Provider Details Display**
- [ ] Select a provider with full data
- [ ] Verify Address displays correctly
- [ ] Verify Phone Number displays correctly
- [ ] Verify Email displays correctly
- [ ] Verify NPI displays correctly

**Test Case 2.3: Provider with Missing Data**
- [ ] Select provider with some missing fields
- [ ] Verify only available fields are shown
- [ ] No "undefined" or error messages appear

### 3. PDF Upload

**Test Case 3.1: Valid PDF with Form Fields**
- [ ] Upload a PDF with fillable fields
- [ ] Verify file name displays correctly
- [ ] Verify file size displays correctly
- [ ] Check fields are extracted

**Test Case 3.2: PDF without Form Fields**
- [ ] Upload a regular (non-form) PDF
- [ ] Verify appropriate message appears
- [ ] No crash or error

**Test Case 3.3: Non-PDF File**
- [ ] Try to upload a .docx or .jpg file
- [ ] Verify error message or rejection
- [ ] App remains functional

**Test Case 3.4: Drag and Drop**
- [ ] Drag a PDF file into the upload area
- [ ] Verify upload works same as clicking
- [ ] Test drag over highlights upload area

### 4. Field Mapping

**Test Case 4.1: Auto-Mapping Quality**
- [ ] Upload a standard medical form
- [ ] Check confidence scores are reasonable
- [ ] Verify high-confidence matches are correct
- [ ] Review medium-confidence matches

**Test Case 4.2: Manual Mapping Override**
- [ ] Change a mapping using the dropdown
- [ ] Verify new value preview updates
- [ ] Ensure custom mapping is used in fill

**Test Case 4.3: Show All Fields Toggle**
- [ ] Toggle "Show all fields" on
- [ ] Verify low-confidence fields appear
- [ ] Toggle off, verify they hide again

**Test Case 4.4: Common Field Recognition**
Test these field name patterns:
- [ ] "Address" / "Mailing Address" / "Street"
- [ ] "Phone" / "Telephone" / "Contact Number"
- [ ] "Email" / "E-mail" / "Electronic Mail"
- [ ] "NPI" / "NPI Number" / "Provider ID"
- [ ] "DEA" / "DEA Number" / "DEA License"

### 5. PDF Filling and Download

**Test Case 5.1: Successful Fill**
- [ ] Complete all steps and click "Fill PDF & Download"
- [ ] Verify download initiates
- [ ] Open filled PDF in Adobe Reader
- [ ] Verify all mapped fields contain correct data
- [ ] Check file name includes provider name

**Test Case 5.2: Empty Fields**
- [ ] Map fields to empty provider data
- [ ] Fill and download PDF
- [ ] Verify empty fields remain empty (no errors)

**Test Case 5.3: Special Characters in Data**
- [ ] Use provider with special chars (é, ñ, etc.)
- [ ] Verify characters display correctly in PDF

### 6. State Management

**Test Case 6.1: Change Provider After Upload**
- [ ] Upload PDF
- [ ] Select first provider
- [ ] Review mappings
- [ ] Select different provider
- [ ] Verify mappings regenerate correctly

**Test Case 6.2: Remove and Re-upload PDF**
- [ ] Upload PDF
- [ ] Click "Remove"
- [ ] Upload same PDF again
- [ ] Verify mappings regenerate

**Test Case 6.3: Refresh Page**
- [ ] Complete workflow partially
- [ ] Refresh browser
- [ ] Verify app resets cleanly
- [ ] No errors in console

### 7. UI/UX

**Test Case 7.1: Responsive Design**
- [ ] Test on desktop (1920x1080)
- [ ] Test on tablet (768px width)
- [ ] Test on mobile (375px width)
- [ ] Verify all elements are accessible

**Test Case 7.2: Loading States**
- [ ] Verify "Processing..." appears during operations
- [ ] Check disabled state on buttons while processing
- [ ] Ensure UI doesn't freeze

**Test Case 7.3: Error Handling**
- [ ] Trigger various errors
- [ ] Verify user-friendly messages
- [ ] Check console for error logs

### 8. Browser Compatibility

**Test Case 8.1: Chrome/Edge**
- [ ] Complete full workflow
- [ ] Check console for errors
- [ ] Verify all features work

**Test Case 8.2: Firefox**
- [ ] Complete full workflow
- [ ] Check console for errors
- [ ] Verify all features work

**Test Case 8.3: Safari**
- [ ] Complete full workflow
- [ ] Check console for errors
- [ ] Verify all features work

## Sample Test Data

### Test Provider Data

Use these providers from the sample CSV:
1. **Doron Stember, MD** - Full data set
2. **Tzvi Doron, DO** - Full data set
3. **Lindsay Burden** - Some missing state licenses

### Sample PDF Forms

Create test PDFs with these field names:

**Basic Form:**
- Provider_Name
- Address
- City
- State
- ZIP
- Phone
- Email
- NPI_Number
- DEA_License

**State License Form:**
- Name
- FL_License
- GA_License
- NY_License
- TX_License

**Contact Form:**
- FullName
- MailingAddress
- TelephoneNumber
- EmailAddress
- NPINumber

## Automated Testing (Future)

### Unit Tests

Create tests for:
- `csvParser.ts` functions
- `pdfUtils.ts` field mapping logic
- Similarity calculation algorithm

### Integration Tests

Test complete workflows:
- CSV upload → Provider selection → PDF upload → Fill → Download
- Edge cases and error scenarios

### Sample Test Structure

```typescript
import { describe, it, expect } from 'vitest';
import { calculateSimilarity } from './pdfUtils';

describe('Field Mapping', () => {
  it('should match exact field names', () => {
    expect(calculateSimilarity('Address', 'Address')).toBe(1.0);
  });
  
  it('should match similar field names', () => {
    expect(calculateSimilarity('Phone', 'Phone Number')).toBeGreaterThan(0.5);
  });
  
  it('should recognize aliases', () => {
    expect(calculateSimilarity('Email', 'E-mail')).toBeGreaterThan(0.7);
  });
});
```

## Performance Testing

### Load Testing

Test with:
- [ ] CSV with 100+ providers
- [ ] PDF with 100+ fields
- [ ] Large PDF files (10MB+)

Verify:
- [ ] No significant lag
- [ ] Memory usage reasonable
- [ ] No browser freezing

### Benchmarks

Acceptable performance:
- CSV parsing: < 1 second for 100 providers
- PDF field extraction: < 2 seconds for 100 fields
- Mapping generation: < 500ms
- PDF filling: < 3 seconds

## Security Testing

### Input Validation

Test malicious inputs:
- [ ] CSV with script injection attempts
- [ ] PDF with embedded JavaScript
- [ ] Very large files (>100MB)
- [ ] Malformed file formats

Verify:
- [ ] No XSS vulnerabilities
- [ ] File size limits enforced
- [ ] Proper error handling

## Accessibility Testing

### Keyboard Navigation

- [ ] Tab through all interactive elements
- [ ] Press Enter/Space on buttons
- [ ] Navigate dropdown with arrow keys
- [ ] Ensure focus indicators visible

### Screen Reader

- [ ] Test with NVDA/JAWS/VoiceOver
- [ ] Verify all labels are read
- [ ] Check form field announcements
- [ ] Ensure error messages are announced

### Color Contrast

- [ ] Verify WCAG AA compliance
- [ ] Test with color blindness simulators
- [ ] Ensure information not conveyed by color alone

## Regression Testing

After any code changes, verify:
- [ ] All manual test cases pass
- [ ] No new console errors
- [ ] Performance hasn't degraded
- [ ] Build completes successfully
- [ ] Deployment works

## Bug Report Template

```markdown
**Summary**: Brief description

**Steps to Reproduce**:
1. Step one
2. Step two
3. Step three

**Expected Behavior**: What should happen

**Actual Behavior**: What actually happens

**Environment**:
- Browser: Chrome 120
- OS: Windows 11
- Version: 1.0.0

**Screenshots**: (if applicable)

**Console Errors**: (if any)
```

## Testing Tools

Recommended tools:
- **Chrome DevTools**: Debugging, network analysis
- **React Developer Tools**: Component inspection
- **Lighthouse**: Performance, accessibility audit
- **WAVE**: Accessibility checker
- **BrowserStack**: Cross-browser testing

## Continuous Testing

Set up automated checks:
- GitHub Actions for build testing
- Lighthouse CI for performance monitoring
- Automated accessibility scans
- Regular security audits
