# Project Structure

This document explains the organization of the Provider PDF Form Filler codebase.

## Directory Structure

```
provider-pdf-filler/
├── src/                          # Source code
│   ├── components/               # React components
│   │   ├── ProviderSelector.tsx  # Provider dropdown with search
│   │   ├── PDFUploader.tsx       # PDF drag-and-drop uploader
│   │   └── FieldMapper.tsx       # Field mapping review interface
│   ├── utils/                    # Utility functions
│   │   ├── csvParser.ts          # CSV parsing logic
│   │   └── pdfUtils.ts           # PDF manipulation with pdf-lib
│   ├── types/                    # TypeScript type definitions
│   │   └── index.ts              # All type interfaces
│   ├── App.tsx                   # Main application component
│   ├── main.tsx                  # Application entry point
│   └── index.css                 # Global styles + Tailwind
├── public/                       # Static assets (if any)
├── examples.ts                   # Programmatic usage examples
├── sample-provider-data.json     # Sample provider data structure
├── sample-provider-data.csv      # Sample CSV file
├── package.json                  # Dependencies and scripts
├── tsconfig.json                 # TypeScript configuration
├── vite.config.ts                # Vite build configuration
├── tailwind.config.js            # Tailwind CSS configuration
├── postcss.config.js             # PostCSS configuration
├── index.html                    # HTML entry point
├── README.md                     # Main documentation
├── QUICKSTART.md                 # Quick start guide
├── DEPLOYMENT.md                 # Deployment instructions
├── TESTING.md                    # Testing guide
└── .gitignore                    # Git ignore rules
```

## Key Files Explained

### Core Application Files

**`src/App.tsx`**
- Main application component
- Manages application state
- Orchestrates workflow between components
- Handles data flow and processing

**`src/components/ProviderSelector.tsx`**
- Searchable dropdown for provider selection
- Displays provider details on selection
- Manages search state and filtering

**`src/components/PDFUploader.tsx`**
- Drag-and-drop file upload interface
- Handles PDF file selection
- Shows uploaded file details

**`src/components/FieldMapper.tsx`**
- Displays auto-detected field mappings
- Shows confidence scores
- Allows manual mapping adjustments
- Provides value previews

### Utility Modules

**`src/utils/csvParser.ts`**
- Parses Provider Compliance Dashboard CSV
- Handles multi-line provider names
- Extracts provider data into structured format
- Exports provider JSON generation

**`src/utils/pdfUtils.ts`**
- PDF field extraction using pdf-lib
- Intelligent field mapping algorithm
- Similarity calculation for field names
- PDF filling and download functionality

### Type Definitions

**`src/types/index.ts`**
- `ProviderData`: Provider information structure
- `PDFField`: PDF form field metadata
- `FieldMapping`: Mapping between PDF and provider fields
- Other type interfaces

### Configuration Files

**`package.json`**
- Project dependencies
- Build scripts
- Project metadata

**`vite.config.ts`**
- Vite build tool configuration
- React plugin setup
- Build optimizations

**`tailwind.config.js`**
- Tailwind CSS customization
- Content paths for purging
- Theme extensions

**`tsconfig.json`**
- TypeScript compiler options
- Path mappings
- Type checking rules

## Data Flow

```
1. CSV Upload
   └─> csvParser.parseCSVFile()
       └─> ParsedProviderData
           └─> App state (providers array)

2. Provider Selection
   └─> ProviderSelector component
       └─> App state (selectedProvider)

3. PDF Upload
   └─> PDFUploader component
       └─> pdfUtils.extractPDFFields()
           └─> PDFField[]
               └─> pdfUtils.generateFieldMappings()
                   └─> FieldMapping[]
                       └─> App state (fieldMappings)

4. Field Mapping Review
   └─> FieldMapper component
       └─> User customizations
           └─> App state (customMappings)

5. PDF Fill & Download
   └─> pdfUtils.fillPDF()
       └─> pdfUtils.downloadPDF()
           └─> Filled PDF file
```

## Component Communication

```
App (Root Component)
├── Manages all state
├── Coordinates data flow
└── Passes data/callbacks to children
    │
    ├── ProviderSelector
    │   ├── Receives: providers array, selectedProvider, onSelect callback
    │   └── Emits: provider selection via onSelect
    │
    ├── PDFUploader
    │   ├── Receives: onFileUpload callback, currentFile
    │   └── Emits: file selection via onFileUpload
    │
    └── FieldMapper
        ├── Receives: mappings array, provider, onMappingsChange callback
        └── Emits: custom mappings via onMappingsChange
```

## Build Process

```
Development:
npm run dev
  └─> Vite dev server
      └─> Hot module replacement
      └─> http://localhost:5173

Production:
npm run build
  └─> TypeScript compilation (tsc)
  └─> Vite build
      ├─> Code splitting
      ├─> Minification
      ├─> Asset optimization
      └─> dist/ folder
          └─> index.html
          └─> assets/
              ├─> [hash].js
              └─> [hash].css
```

## State Management

Currently using React's built-in state management:
- `useState` for component-level state
- `useEffect` for side effects
- Props for parent-child communication

For future expansion, consider:
- Context API for global state
- Zustand for state management
- React Query for async operations

## Styling Architecture

- **Tailwind CSS**: Utility-first CSS framework
- **Custom CSS**: Minimal, in `index.css`
- **Component Styling**: Inline Tailwind classes
- **Responsive Design**: Mobile-first approach

## Performance Optimizations

- **Code Splitting**: Automatic via Vite
- **Tree Shaking**: Removes unused code
- **Lazy Loading**: Can be added for routes
- **Memoization**: Can be added with useMemo/useCallback

## Testing Strategy

Currently manual testing. For future:
- **Unit Tests**: Vitest for utils
- **Component Tests**: React Testing Library
- **E2E Tests**: Playwright or Cypress
- **Type Tests**: TypeScript compiler

## Future Enhancements

Potential additions:
- [ ] Multiple PDF batch processing
- [ ] Save mapping templates
- [ ] Provider data editing
- [ ] Export filled PDFs as ZIP
- [ ] Integration with cloud storage
- [ ] Advanced field mapping rules
- [ ] PDF preview before download
- [ ] History of filled forms
- [ ] User accounts and sessions

## Dependencies

### Production Dependencies
- `react` - UI framework
- `react-dom` - React DOM rendering
- `pdf-lib` - PDF manipulation

### Development Dependencies
- `typescript` - Type safety
- `vite` - Build tool
- `@vitejs/plugin-react` - React support for Vite
- `tailwindcss` - CSS framework
- `autoprefixer` - CSS vendor prefixes
- `postcss` - CSS processing
- `eslint` - Code linting

## Browser Compatibility

Targets:
- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- No IE11 support (uses modern JavaScript)

## License

MIT License - See project root for full license text.
