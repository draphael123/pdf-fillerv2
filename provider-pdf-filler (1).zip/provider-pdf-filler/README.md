# Provider PDF Form Filler

A professional web application that automatically populates PDF forms with provider data from your Provider Compliance Dashboard. Built with React, TypeScript, Tailwind CSS, and pdf-lib.

## Features

✨ **Smart Field Mapping** - Automatically detects and maps PDF form fields to provider data with confidence scoring
🎯 **Intelligent Matching** - Uses fuzzy matching and common field name patterns to suggest the best mappings
📝 **Manual Override** - Review and customize any field mapping before filling
📊 **Provider Dashboard Integration** - Directly parse your Provider Compliance Dashboard CSV
🔍 **Searchable Provider Selection** - Quickly find any provider from your database
💾 **Instant Download** - Fill and download PDFs with one click
🎨 **Modern UI** - Clean, professional interface built with Tailwind CSS

## How It Works

1. **Upload Provider Data** - Load your Provider Compliance Dashboard CSV file
2. **Select Provider** - Choose which provider's information to use
3. **Upload PDF Form** - Upload any PDF form with fillable fields
4. **Review Mappings** - Check the auto-detected field mappings (with confidence scores)
5. **Customize** - Adjust any mappings that need correction
6. **Download** - Generate and download the filled PDF

## Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd provider-pdf-filler

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Usage

### Step 1: Prepare Your Provider Data

Your Provider Compliance Dashboard CSV should have:
- **Column 1**: Field names (Address, Phone Number, Email, NPI Number, State Licenses, etc.)
- **Subsequent Columns**: Provider data (one provider per column)

Example structure:
```csv
Column 1,Doron Stember MD,Tzvi Doron DO,...
Address,"208 East Broadway, NY, NY 10002","276 Thorn St, Oceanside, NY 11572",...
Phone Number,555-0100,555-0101,...
Email,doron@example.com,tzvi@example.com,...
NPI Number,1234567890,0987654321,...
```

### Step 2: Upload Your CSV

When you first load the app, upload your Provider Compliance Dashboard CSV file. The app will automatically parse it and make all providers available for selection.

### Step 3: Select a Provider

Use the searchable dropdown to select the provider whose information you want to use. The provider's details (address, phone, email, NPI) will be displayed for verification.

### Step 4: Upload a PDF Form

Upload any PDF form that has fillable fields. The app will automatically:
- Extract all form field names
- Generate smart mappings to your provider data
- Calculate confidence scores for each mapping

### Step 5: Review Field Mappings

The app shows all detected mappings with confidence scores:
- **High (80%+)**: Very likely correct
- **Medium (50-79%)**: Probably correct, worth reviewing
- **Low (<50%)**: Needs review and likely adjustment

You can:
- View suggested values before filling
- Change any mapping using the dropdowns
- See exactly what data will be filled into each field

### Step 6: Fill & Download

Click "Fill PDF & Download" to generate your completed form. The file will be named `ProviderName_OriginalFilename.pdf`.

## Technical Architecture

### Component Structure

```
src/
├── components/
│   ├── ProviderSelector.tsx   # Searchable provider dropdown with details
│   ├── PDFUploader.tsx         # Drag-and-drop PDF upload
│   └── FieldMapper.tsx         # Field mapping review and customization
├── utils/
│   ├── csvParser.ts            # Parse Provider Compliance Dashboard CSV
│   └── pdfUtils.ts             # PDF field extraction, mapping, and filling
├── types/
│   └── index.ts                # TypeScript type definitions
├── App.tsx                     # Main application component
└── main.tsx                    # Application entry point
```

### Smart Field Mapping Algorithm

The field mapper uses several techniques:

1. **Exact Match**: Direct string matching (normalized)
2. **Substring Match**: One field contains the other
3. **Keyword Match**: Common words overlap
4. **Alias Mapping**: Recognizes common variations (e.g., "tel" → "phone")

Common field mappings include:
- Address → street, addr, mailing, physical, residence
- Phone → tel, telephone, mobile, cell, contact
- Email → e-mail, mail, electronic
- NPI → npi number, national provider, provider id
- DEA → dea number, dea license
- License → license number, state license, medical license

### Sample Provider Data JSON

```json
{
  "name": "Doron Stember, MD",
  "data": {
    "Address": "208 East Broadway J-1306, NY, NY 10002",
    "Phone Number": "555-0100",
    "Email": "doron.stember@example.com",
    "NPI Number": "1234567890",
    "DEA License Number": "DS1234563",
    "FL": "ME147501",
    "GA": "89666",
    "NY": "241937",
    "TX": "S9802"
  }
}
```

## Development

### Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Styling
- **pdf-lib** - PDF manipulation
- **ESLint** - Code linting

### Available Scripts

```bash
npm run dev      # Start development server (http://localhost:5173)
npm run build    # Build for production
npm run preview  # Preview production build
npm run lint     # Run ESLint
```

### Adding New Features

To add new field mapping patterns:

1. Edit `src/utils/pdfUtils.ts`
2. Add entries to the `COMMON_MAPPINGS` object:

```typescript
const COMMON_MAPPINGS: Record<string, string[]> = {
  'your_field': ['alias1', 'alias2', 'alias3'],
  // ...
};
```

## Deployment

### Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Deploy to Netlify

```bash
# Build the project
npm run build

# Deploy the dist/ folder to Netlify
```

## Troubleshooting

### PDF Fields Not Detected

**Problem**: "No fillable fields detected in the PDF"

**Solution**: Your PDF may not have fillable form fields. Use Adobe Acrobat or a similar tool to add form fields to your PDF first.

### Low Confidence Mappings

**Problem**: All mappings show low confidence scores

**Solution**: Your PDF field names may be very different from your provider data field names. Manually review and adjust the mappings using the dropdowns.

### CSV Not Parsing Correctly

**Problem**: Providers not appearing or data looks wrong

**Solution**: Ensure your CSV follows the expected format:
- Column 1 contains field names
- Provider names in header rows
- Data starts after header section
- Use quotes around values containing commas

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

## License

MIT License - feel free to use this in your own projects!

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues or questions, please open an issue on GitHub.
