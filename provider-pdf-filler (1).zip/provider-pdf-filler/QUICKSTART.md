# Quick Start Guide

Get up and running with the Provider PDF Form Filler in 5 minutes!

## Prerequisites

- Node.js 18+ installed
- A Provider Compliance Dashboard CSV file
- A PDF form with fillable fields

## Step 1: Install Dependencies

```bash
npm install
```

## Step 2: Start the Development Server

```bash
npm run dev
```

The app will open at `http://localhost:5173`

## Step 3: Load Your Provider Data

1. Click "Upload Provider Compliance CSV"
2. Select your Provider Compliance Dashboard CSV file
3. Wait for the data to load

**Sample CSV included**: `sample-provider-data.csv`

## Step 4: Use the Application

### Basic Workflow

1. **Select a Provider**
   - Click the dropdown
   - Search or browse for a provider
   - Click to select

2. **Upload a PDF Form**
   - Drag and drop a PDF file, or
   - Click to browse and select

3. **Review Mappings**
   - The app auto-detects field mappings
   - Review confidence scores
   - Adjust any mappings if needed

4. **Download**
   - Click "Fill PDF & Download"
   - Your filled PDF will download automatically

## Sample Data Format

Your CSV should look like this:

```csv
Column 1,Provider 1,Provider 2,...
Address,"123 Main St","456 Oak Ave",...
Phone Number,"555-0100","555-0101",...
Email,"doc1@example.com","doc2@example.com",...
NPI Number,"1234567890","0987654321",...
```

## Common Issues

### Issue: No providers showing up
**Solution**: Make sure your CSV has the correct format with provider names in the header rows and data starting with field names like "Address", "Phone Number", etc.

### Issue: No fillable fields detected
**Solution**: Your PDF needs to have actual form fields. Use Adobe Acrobat to add form fields to your PDF first.

### Issue: Low confidence mappings
**Solution**: PDF field names are very different from your data fields. Manually select the correct mappings using the dropdowns.

## Next Steps

- Read the full [README.md](./README.md) for detailed documentation
- Check [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment
- See [examples.ts](./examples.ts) for programmatic usage

## Need Help?

Open an issue on GitHub or check the troubleshooting section in the README.
