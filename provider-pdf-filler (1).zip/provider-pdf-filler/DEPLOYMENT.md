# Deployment Guide

This guide covers deploying the Provider PDF Form Filler to various platforms.

## Table of Contents

- [Vercel (Recommended)](#vercel)
- [Netlify](#netlify)
- [GitHub Pages](#github-pages)
- [Custom Server](#custom-server)

---

## Vercel

**Recommended for beginners** - Zero configuration needed!

### Method 1: Vercel CLI

```bash
# Install Vercel CLI globally
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Follow the prompts to configure your project
```

### Method 2: GitHub Integration

1. Push your code to GitHub
2. Visit [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect Vite and configure everything
6. Click "Deploy"

### Environment Variables

No environment variables needed! The app runs entirely client-side.

### Custom Domain

1. Go to your project settings in Vercel
2. Navigate to "Domains"
3. Add your custom domain
4. Follow DNS configuration instructions

---

## Netlify

### Method 1: Netlify CLI

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build the project
npm run build

# Deploy
netlify deploy --prod --dir=dist
```

### Method 2: Drag and Drop

1. Build your project: `npm run build`
2. Go to [app.netlify.com](https://app.netlify.com)
3. Drag and drop the `dist/` folder

### Method 3: GitHub Integration

1. Push code to GitHub
2. Visit [app.netlify.com](https://app.netlify.com)
3. Click "New site from Git"
4. Connect your repository
5. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Click "Deploy site"

---

## GitHub Pages

### Prerequisites

- GitHub repository
- GitHub Actions enabled

### Step 1: Create GitHub Action

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v2
        with:
          path: ./dist

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v2
```

### Step 2: Update vite.config.ts

```typescript
export default defineConfig({
  plugins: [react()],
  base: '/your-repo-name/', // Add this line
  optimizeDeps: {
    exclude: ['pdf-lib']
  }
})
```

### Step 3: Enable GitHub Pages

1. Go to your repository settings
2. Navigate to "Pages"
3. Source: GitHub Actions
4. Push to main branch

Your site will be available at: `https://username.github.io/your-repo-name/`

---

## Custom Server

### Prerequisites

- Node.js 18+ on server
- Nginx or Apache (optional, for serving)

### Option 1: Serve with Node.js

```bash
# On your server
git clone <your-repo>
cd provider-pdf-filler
npm install
npm run build

# Install a static file server
npm install -g serve

# Serve the built files
serve -s dist -p 3000
```

### Option 2: Serve with Nginx

1. Build the project:
```bash
npm run build
```

2. Copy `dist/` to your web server:
```bash
scp -r dist/* user@server:/var/www/provider-pdf-filler/
```

3. Configure Nginx (`/etc/nginx/sites-available/provider-pdf-filler`):
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/provider-pdf-filler;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Optional: Enable gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

4. Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/provider-pdf-filler /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Option 3: Serve with Apache

1. Build and copy files as above

2. Configure Apache (`.htaccess` in your web root):
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

---

## Docker Deployment

### Dockerfile

Create a `Dockerfile`:

```dockerfile
FROM node:18-alpine as build

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### nginx.conf

```nginx
server {
    listen 80;
    location / {
        root /usr/share/nginx/html;
        index index.html index.htm;
        try_files $uri $uri/ /index.html;
    }
}
```

### Build and Run

```bash
# Build the image
docker build -t provider-pdf-filler .

# Run the container
docker run -d -p 80:80 provider-pdf-filler
```

---

## Performance Optimization

### Build Optimizations

Already included in `vite.config.ts`:
- Code splitting
- Tree shaking
- Minification
- Asset optimization

### Additional Optimizations

1. **Enable HTTPS**
   - Use Let's Encrypt for free SSL certificates
   - All major platforms (Vercel, Netlify) provide automatic HTTPS

2. **CDN Configuration**
   - Vercel and Netlify include global CDN automatically
   - For custom servers, consider Cloudflare

3. **Caching Headers**
   ```nginx
   location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
       expires 1y;
       add_header Cache-Control "public, immutable";
   }
   ```

---

## Monitoring and Analytics

### Add Analytics

Add to `index.html` before `</head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Error Tracking

Consider integrating:
- Sentry
- LogRocket
- Bugsnag

---

## Security Considerations

1. **HTTPS Only**: Always deploy with HTTPS enabled
2. **CSP Headers**: Consider adding Content Security Policy headers
3. **No Sensitive Data**: All processing happens client-side
4. **Regular Updates**: Keep dependencies updated

---

## Troubleshooting Deployment

### Build Fails

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Routes Not Working

Make sure your server is configured for single-page apps (SPA). All routes should serve `index.html`.

### Assets Not Loading

Check the `base` URL in `vite.config.ts` matches your deployment path.

---

## Recommended Platform

**For most users: Vercel**

Why?
- ✅ Zero configuration
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Free tier includes generous limits
- ✅ GitHub integration
- ✅ Preview deployments for PRs

Simply push to GitHub and connect to Vercel - you'll be live in minutes!
